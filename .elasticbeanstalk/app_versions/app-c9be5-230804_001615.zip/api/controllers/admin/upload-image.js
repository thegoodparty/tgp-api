module.exports = async function uploadAvatar(req, res) {
  const file = req.file('files[0]');
  try {
    const response = await sails.helpers.images.uploadImage(file);
    return res.ok(response);
  } catch (e) {
    return res.badRequest('error uploading image');
  }
};
